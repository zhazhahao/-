#include <stdio.h>
#include <stdlib.h>     //exit()函数，atoi()函数
#include <unistd.h>     //提供对 POSIX 操作系统 API 的访问功能的头文件
#include <sys/types.h>  //Linux系统的基本系统数据类型的头文件,含有size_t,time_t,pid_t等类型
#include <sys/socket.h> //套接字基本函数
#include <netinet/in.h> //IP地址和端口相关定义，比如struct sockaddr_in等
#include <arpa/inet.h>  //inet_pton()等函数
#include <string.h>     //bzero()函数

#define MAX_BUFFER_SIZE 120

int main(int argc, char *argv[])
{

    const char *ip_address = argv[1];
    in_port_t port = atoi(argv[2]); // 解析命令行参数，获取服务器的IP地址和端口号

    int client_socket;
    struct sockaddr_in server_addr;
    socklen_t server_addr_len = sizeof(server_addr);
    char inbuffer[122];
    char outbuffer[137];
    if (argc != 3)
    { // 判断命令行参数数量是否正确
        printf("Usage: %s <ip_address> <port>\n", argv[0]);
        exit(EXIT_FAILURE); // 若参数数量不正确，则退出程序
    }
    // 创建TCP套接字
    if ((client_socket = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {                                     // 创建一个TCP套接字
        perror("socket creation failed"); // 若创建套接字失败，则输出错误信息
        exit(EXIT_FAILURE);
    }

    // 设置服务器地址和端口
    bzero(&server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);                  // 设置端口号，并将主机字节序转换为网络字节序
    server_addr.sin_addr.s_addr = inet_addr(ip_address); // 设置服务器的IP地址，并将字符串形式的IP地址转换为网络字节序的二进制形式

    // 连接服务器
    if (connect(client_socket, (struct sockaddr *)&server_addr, server_addr_len) == -1)
    {                             // 通过套接字连接服务器
        perror("connect failed"); // 若连接服务器失败，则输出错误信息
        exit(EXIT_FAILURE);
    }
    else
        printf("[cli] server[%s:%d] is connected!\n", ip_address, port); // 连接成功后，输出连接成功的信息

    while (1)
    { // 循环等待用户输入并发送给服务器
       
        fgets(inbuffer, sizeof(inbuffer), stdin); // 从标准输入读取用户的输入消息
        ssize_t s = strlen(inbuffer);
        inbuffer[s] = '\0';

        printf("[ECH_RQT]%s", inbuffer); // 输出从标准输入读取的信息
        char checkchar[6] = {'E', 'X', 'I', 'T', '\n', '\0'};
        if (!strncmp(inbuffer, checkchar, 6)) // 如果buf_in等于"EXIT\n"，则退出
        {
            break;
        }
        if (s > 0)
        {
            // 发送消息给服务器

            write(client_socket, inbuffer, strlen(inbuffer) + 1);
                                  

            
            
            if (read(client_socket, outbuffer, 8 + strlen(inbuffer)) > 0)
            {
                printf("[ECH_REP]%s", outbuffer);
            }
        }
    }
    fflush(stdout);
    printf("[cli] connfd is closed!\n[cli] client is to return!\n");
    close(client_socket); // 关闭客户端套接字
    return 0;             // 程序正常结束
}