// 包含需要使用的头文件
#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <stdint.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#define BUF_SIZE 150 // 定义数据读写缓冲区的大小

int server_fd, new_socket, len;
struct sockaddr_in address;
int opt = 1;
char buffer[BUF_SIZE] = {0};


int sigint_flag = 0; // SIGINT信号标志

// SIGINT信号处理器
void sigint_handler(int signum)
{
    sigint_flag = 1;
}

int main(int argc, char *argv[])
{
    // 定义SIGINT信号处理结构体sa，并设置相应的属性
    struct sigaction sa;
    sa.sa_flags = 0;
    sa.sa_handler = sigint_handler;
    sigemptyset(&sa.sa_mask);

    // 将SIGINT信号与上述处理结构体sa关联起来
    sigaction(SIGINT, &sa, NULL);

    if (argc != 4)
    {
        printf("Usage: %s <ip_address> <port> <veri_code>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    char *ip_address = argv[1];
    int port = atoi(argv[2]);
    char *veri_code = argv[3];

    // 安装SIGINT信号处理器
    signal(SIGINT, sigint_handler);

    // 创建套接字
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0)
    {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }

    // 设置套接字选项
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)))
    {
        perror("setsockopt failed");
        exit(EXIT_FAILURE);
    }

    // 设置服务器信息
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = inet_addr(ip_address);
    address.sin_port = htons(port);

    // 将套接字绑定到端口号
    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0)
    {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }

    // 启动监听，等待连接
    if (listen(server_fd, 5) < 0)
    {
        perror("listen failed");
        exit(EXIT_FAILURE);
    }
    else
    {
        printf("[srv] server[%s:%d][%s] is initializing!\n​", ip_address, port, veri_code);
        printf("[srv] server has initialized!\n");
    }

    // 处理来自客户端的数据
    while (!sigint_flag)
    {

        // 接受连接请求
        if ((new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t *)&len)) < 0)
        {
            if (errno == EINTR) // 如果调用被信号中断了，则继续循环
            {
                continue;
            }
            else // 否则输出错误信息，并结束循环
            {
                perror("accept");
                break;
            }
        }
        else
        {
            printf("[srv] client[%s:%d] is accepted!\n​", ip_address, port);
        }

        while (1)
        {
            memset(buffer, 0, BUF_SIZE);
            ssize_t s = read(new_socket, buffer, 150);
            // 从客户端读取数据
            if ( s < 0)
            {
                perror("read failed");
                exit(EXIT_FAILURE);
            }

            // 如果客户端关闭连接，则退出循环
           else  if (s == 0)
            {
                close(new_socket);
                printf("[srv] client[%s:%d] is closed!\n", ip_address, port);
                break;
            }
            if(s>0){
            printf("[ECH_RQT]%s", buffer);
            char send_buf[8+ s];
         
            memset(send_buf, '\0', 8+ s + 1);
    
           
            
            sprintf(send_buf,"(%s)",veri_code);
            strcat(send_buf,buffer);
            int endpoint = strlen(send_buf);
            send_buf[endpoint] = '\0';
            write(new_socket, send_buf, strlen(send_buf) + 1);
        }
        }

    }

    // 关闭套接字和连接
   
    close(server_fd);
    if (sigint_flag)
    {
        printf("Server is terminated by interrupt signal.\n");
    }
    else
    {
        printf("Server is terminated normally.\n");
    }
    return 0;
}
